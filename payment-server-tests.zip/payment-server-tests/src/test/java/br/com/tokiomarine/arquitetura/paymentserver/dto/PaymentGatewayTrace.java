package br.com.tokiomarine.arquitetura.paymentserver.dto;

import java.util.HashMap;
import java.util.Map;



public class PaymentGatewayTrace {

	private PaymentGateway gateway;

	private final Map<String, Object> items = new HashMap<String, Object>();

	public PaymentGateway getGateway() {
		return gateway;
	}

	public void setGateway(PaymentGateway gateway) {
		this.gateway = gateway;
	}

	public Map<String, Object> getItems() {
		return items;
	}

	public Object getItem(String key) {
		return items.get(key);
	}

	public Object addItem(String key, Object value) {
		return items.put(key, value);
	}
}

