package br.com.tokiomarine.arquitetura.paymentserver.dto;

public enum PaymentGateway {

	MUNDIPAGG, CIELO15;

}
