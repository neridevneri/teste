package br.com.tokiomarine.arquitetura.paymentserver.web.rest;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;

import br.com.tokiomarine.arquitetura.paymentserver.builders.BuilderCreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.builders.BuilderCustomer;
import br.com.tokiomarine.arquitetura.paymentserver.builders.BuilderPayment;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Brand;
import br.com.tokiomarine.arquitetura.paymentserver.dto.CreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Customer;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Payment;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class PaymentControllerTest {

	@Value("${app.baseURI}")
	private String baseURI;

	@Before
	public void setup() {
		RestAssured.baseURI = baseURI;
		RestAssured.given().contentType(ContentType.JSON);
		RestAssured.given().headers("gateway", "MUNDIPAGG");

	}

	@Test
	public void paymentsListTest() {//@formatter:off
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/payments")
				.then()
				.statusCode(200).log().all();
	}//@formatter:on

	@Test
	public void paymentsCreateTest() throws JsonProcessingException {//@formatter:off
		Customer customer = new BuilderCustomer()
				.name("Tokio Marine Test")
				.build();
		
		CreditCard creditCard = new BuilderCreditCard()
				.customer(customer)
				.brand(Brand.VISA)
				.cvv("399").expMonth(8)
				.expYear(2020)
				.holder("Tokio Marine Test")
				.number("4556379742764523")
				.build();
		
		Payment payment = new BuilderPayment().amount(4).creditCard(creditCard).build();

		ObjectMapper mapper = new ObjectMapper();
				given().auth()
				.basic("admin", "admin")
				.contentType("application/json")	
				.body(mapper.writeValueAsString(payment))
				.when()
				.post("v1/payments")
				.then()
				.statusCode(201)
				.body("creditCard.cvv", equalTo("399"))
				.body("creditCard.brand", equalTo(Brand.VISA.toString()))
				.body("creditCard.holder", equalTo("Tokio Marine Test")).log().all();
	}//@formatter:on

	@Test
	public void paymentsReadTest() {//@formatter:off
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/payments/5bbd0f313de5f237e06ab35c")
				.then()
				.statusCode(200).log().all();		
	}//@formatter:on

	@Test
	public void paymentsProcessTest() throws JsonProcessingException {//@formatter:off
		Customer customer = new BuilderCustomer()
				.name("Tokio Marine Test")
				.build();
		CreditCard creditCard = new BuilderCreditCard()
				.customer(customer)
				.brand(Brand.VISA)
				.cvv("399").expMonth(8)
				.expYear(2020)
				.holder("Tokio Marine Test")
				.number("4556379742764523")
				.build();
		Payment payment = new BuilderPayment().amount(4).creditCard(creditCard).id("5bbd0f313de5f237e06ab35c").build();

		ObjectMapper mapper = new ObjectMapper();
				given().auth()
				.basic("admin", "admin")
				.contentType("application/json")	
				.body(mapper.writeValueAsString(payment))
				.when()
				.post("v1/payments")
				.then()
				.statusCode(201)
				.body("creditCard.cvv", equalTo("399"))
				.body("creditCard.brand", equalTo(Brand.VISA.toString()))
				.body("creditCard.holder", equalTo("Tokio Marine Test")).log().all();
	}//@formatter:on

	@Test
	public void paymentsGatewayTraceTest() {//@formatter:off
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/payments/5bbd0f313de5f237e06ab35c/trace")
				.then()
				.statusCode(200).log().all();
	}//@formatter:on

}
