package br.com.tokiomarine.arquitetura.paymentserver.builders;

import br.com.tokiomarine.arquitetura.paymentserver.dto.Customer;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Brand;
import br.com.tokiomarine.arquitetura.paymentserver.dto.CreditCard;

public class BuilderCreditCard {

	private CreditCard requestPayment;

	public BuilderCreditCard() {
		requestPayment = new CreditCard();
	}

	public BuilderCreditCard brand(Brand brand) {
		requestPayment.setBrand(brand);
		return this;
	}

	public BuilderCreditCard cvv(String cvv) {
		requestPayment.setCvv(cvv);
		return this;
	}

	public BuilderCreditCard customer(Customer customer) {
		requestPayment.setCustomer(customer);
		return this;
	}

	public BuilderCreditCard expMonth(int expMonth) {
		requestPayment.setExpMonth(expMonth);
		return this;
	}

	public BuilderCreditCard expYear(int expYear) {
		requestPayment.setExpYear(expYear);
		return this;
	}

	public BuilderCreditCard id(String id) {
		requestPayment.setId(id);
		return this;
	}

	public BuilderCreditCard holder(String holder) {
		requestPayment.setHolder(holder);
		return this;
	}

	public BuilderCreditCard number(String number) {
		requestPayment.setNumber(number);
		return this;
	}

	public CreditCard build() {
		return requestPayment;
	}

}
