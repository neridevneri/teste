package br.com.tokiomarine.arquitetura.paymentserver;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import br.com.tokiomarine.arquitetura.paymentserver.web.rest.CancelPaymentTest;
import br.com.tokiomarine.arquitetura.paymentserver.web.rest.CreateCreditCardTest;
import br.com.tokiomarine.arquitetura.paymentserver.web.rest.CreatePaymentTest;
import br.com.tokiomarine.arquitetura.paymentserver.web.rest.CreditCardControllerTest;
import br.com.tokiomarine.arquitetura.paymentserver.web.rest.PaymentControllerTest;
import br.com.tokiomarine.arquitetura.paymentserver.web.rest.RestTemplateTest;

@RunWith(Suite.class)
@Suite.SuiteClasses({ CancelPaymentTest.class, CreateCreditCardTest.class, CreatePaymentTest.class, CreditCardControllerTest.class, PaymentControllerTest.class, RestTemplateTest.class })
public class PaymentServerTestsApplicationTests {

	@Test
	public void contextLoads() {
	}
}
