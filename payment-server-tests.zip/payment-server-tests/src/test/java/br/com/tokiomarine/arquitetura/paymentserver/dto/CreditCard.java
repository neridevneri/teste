package br.com.tokiomarine.arquitetura.paymentserver.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class CreditCard {

	private String id;
	private String number;
	private String holder;
	private Integer expMonth;
	private Integer expYear;
	private String cvv;
	private Brand brand;

	private Customer customer;
	
	@JsonIgnore
	private final PaymentGatewayTrace trace = new PaymentGatewayTrace();
	
	public CreditCard() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public String getHolder() {
		return holder;
	}

	public void setHolder(String holder) {
		this.holder = holder;
	}

	public Integer getExpMonth() {
		return expMonth;
	}

	public void setExpMonth(Integer expMonth) {
		this.expMonth = expMonth;
	}

	public Integer getExpYear() {
		return expYear;
	}

	public void setExpYear(Integer expYear) {
		this.expYear = expYear;
	}

	public String getCvv() {
		return cvv;
	}

	public void setCvv(String cvv) {
		this.cvv = cvv;
	}

	public Brand getBrand() {
		return brand;
	}

	public void setBrand(Brand brand) {
		this.brand = brand;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

}
