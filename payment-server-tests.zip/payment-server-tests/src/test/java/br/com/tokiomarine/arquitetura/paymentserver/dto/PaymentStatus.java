package br.com.tokiomarine.arquitetura.paymentserver.dto;

public enum PaymentStatus {

	PENDING, PROCESSING, APPROVED, CANCELED, FAILURED;

}
