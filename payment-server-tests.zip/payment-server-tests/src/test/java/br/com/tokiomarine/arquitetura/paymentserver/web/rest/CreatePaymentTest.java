package br.com.tokiomarine.arquitetura.paymentserver.web.rest;

import static com.jayway.restassured.RestAssured.basic;
import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.not;

import java.io.File;
import java.util.Map;
import java.util.UUID;

import org.hamcrest.collection.IsMapContaining;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CreatePaymentTest {

	@Value("${payment-server.baseURI}")
	private String baseURI;

	@Value("${payment-server.username}")
	private String username;

	@Value("${payment-server.password}")
	private String password;

	private ObjectMapper objectMapper = new ObjectMapper();

	@Before
	public void setup() {
		System.setProperty("http.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("http.proxyPort", "8080");
		System.setProperty("https.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("https.proxyPort", "8080");

		RestAssured.baseURI = baseURI;
		RestAssured.authentication = basic(username, password);
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
		RestAssured.requestSpecification = new RequestSpecBuilder().setContentType(ContentType.JSON)
				.setAccept(ContentType.JSON).build();
	}

	@Test
	public void createSimplePayment() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-simple-payment.json");

		given().			
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).
	    	body("status", equalTo("APPROVED"));
		
	} // @formatter:on

	@Test
	public void createCielo15Payment() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-cielo15-payment.json");

		given().
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).
	    	body("gateway", equalTo("CIELO15")).
	    	body("status", equalTo("APPROVED"));	    	
		
	} // @formatter:on	

	@Test
	public void createMundipaggPayment() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-mundipagg-payment.json");

		given().
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).
	    	body("gateway", equalTo("MUNDIPAGG")).
	    	body("status", equalTo("APPROVED"));		
		
	} // @formatter:on		

	@Test
	public void createCielo15PaymentWithNativeToken() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-cielo15-payment-with-native-token.json");

		given().
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).
	    	body("gateway", equalTo("CIELO15")).
	    	body("status", equalTo("APPROVED"));
		
	} // @formatter:on	

	@Test
	public void createPaymentWithCardId() throws Throwable { // @formatter:off
		String cardId = createACardForTest();
		
		JsonNode json = getRequestBody("create-payment-with-card-id.json");		
		((ObjectNode)json.get("creditCard")).put("id", cardId);		
		
		given().
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).	    	
	    	body("status", equalTo("APPROVED"));
				
	} // @formatter:on	

	@Test
	public void createPaymentWithInvalidCardId() throws Throwable { // @formatter:off		
		JsonNode json = getRequestBody("create-payment-with-card-id.json");		
		
		((ObjectNode)json.get("creditCard")).put("id", UUID.randomUUID().toString());		
		
		given().			
			body(json).
		when().
	       post("v1/payments").
	    then().	    	
	    	statusCode(400).
	    	body("violations.'creditCard.id'", equalTo("Credit card id not found"));

	} // @formatter:on	

	@Test
	public void createPaymentWithDepartment() throws Throwable { // @formatter:off		
		JsonNode json = getRequestBody("create-payment-with-department.json");		
		
		String departmentName = json.get("department").get("name").asText();
		
		given().	
			auth().basic("financeiros-resseguros", "1234").
			body(json).
		when().
	       post("v1/payments").
	    then().	    	
	    	statusCode(201).
	    	body("id", not(isEmptyString())).	    	
	    	body("status", equalTo("APPROVED")).
	    	body("department.name", equalTo(departmentName));

	} // @formatter:on	

	@Test
	public void createPaymentWithDepartmentShouldFail() throws Throwable { // @formatter:off		
		JsonNode json = getRequestBody("create-payment-with-department.json");		
		
		given().		
			auth().basic("user", "user").
			body(json).
		when().
	       post("v1/payments").
	    then().	    	
	    	statusCode(400).
	    	body("message", equalTo("Validation Failed")).
	    	body("violations.'department.name'", equalTo("Departament not allowed"));

	} // @formatter:on		

	@Test
	public void createPaymentWithInvalidData() throws Throwable { // @formatter:off		
		JsonNode json = getRequestBody("create-payment-with-invalid-data.json");		
		
		Map<String, String> violations = given().			
			body(json).
		when().
	       post("v1/payments").
	    then().	    	
	    	statusCode(400).
	    extract()
	    	.path("violations");	

		assertThat(violations, IsMapContaining.hasKey("amount"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.expMonth"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.brand"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.number"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.expYear"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.holder"));		 
		assertThat(violations, IsMapContaining.hasKey("creditCard.customer.name"));
		assertThat(violations, IsMapContaining.hasKey("creditCard.customer.document"));
		
	} // @formatter:on		

	private String createACardForTest() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-credit-card.json");
		
		return given().			
			body(json).
		when().
	       post("v1/credit-cards").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString()))
	    .extract()
	    	.path("id");
		
	} // @formatter:on	

	private JsonNode getRequestBody(String filename) throws Throwable {
		File src = ResourceUtils.getFile("classpath:json/request/" + filename);
		return objectMapper.readValue(src, JsonNode.class);
	}

}
