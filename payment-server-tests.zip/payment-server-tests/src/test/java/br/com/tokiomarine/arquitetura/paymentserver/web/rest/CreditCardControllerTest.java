package br.com.tokiomarine.arquitetura.paymentserver.web.rest;

import static com.jayway.restassured.RestAssured.given;
import static org.hamcrest.Matchers.equalTo;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.http.ContentType;

import br.com.tokiomarine.arquitetura.paymentserver.builders.BuilderCreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.builders.BuilderCustomer;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Brand;
import br.com.tokiomarine.arquitetura.paymentserver.dto.CreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Customer;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class CreditCardControllerTest {

	@Value("${app.baseURI}")
	private String baseURI;

	@Before
	public void setup() {
		RestAssured.baseURI = baseURI;
		RestAssured.given().contentType(ContentType.JSON);
		RestAssured.given().headers("gateway", "MUNDIPAGG");
	}

	@Test
	public void autenthenticateAccepTest() {//@formatter:off
				given()
				.auth()
				.basic("admin", "admin")
				.expect()
				.statusCode(201).log().all();
	}//@formatter:on

	@Test
	public void autenthenticateForbiddenTest() {//@formatter:off
				given()
				.auth()
				.basic("1213", "1213")
				.expect()
				.statusCode(403).log().all();
	}//@formatter:on

	@Test
	public void creditCardsCreateTest() throws InterruptedException, JsonProcessingException {//@formatter:off
		Customer customer = new BuilderCustomer()
				.name("Tokio Marine Test")
				.build();
		CreditCard creditcard = new BuilderCreditCard()
				.customer(customer)
				.brand(Brand.VISA)
				.cvv("399")
				.expMonth(8)
				.expYear(2019)
				.holder("Tokio Marine Test")
				.number("4556379742764523")
				.build();

		ObjectMapper mapper = new ObjectMapper();
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.body(mapper.writeValueAsString(creditcard))
				.when()
				.post("v1/credit-cards")
				.then()
				.statusCode(201)
				.body("brand", equalTo(Brand.VISA.toString()))
				.body("cvv", equalTo("399"))
				.body("holder", equalTo("Tokio Marine Test")).log().all();
	}//@formatter:on

	@Test
	public void creditCardsExpireTest() throws InterruptedException, JsonProcessingException { //@formatter:off
		Customer customer = new BuilderCustomer().name("Tokio Marine Test").build();
		CreditCard creditcard = new BuilderCreditCard()
				.customer(customer)
				.brand(Brand.VISA)
				.cvv("399")
				.expMonth(8)
				.expYear(2010)
				.holder("Tokio Marine Test")
				.number("4556379742764523")
				.build();

		ObjectMapper mapper = new ObjectMapper();
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.body(mapper.writeValueAsString(creditcard))
				.when()
				.post("v1/credit-cards")
				.then()
				.statusCode(400).log().all();
		
	}//@formatter:on

	@Test
	public void requestPaymentCvvSixTest() throws InterruptedException, JsonProcessingException {//@formatter:off
		Customer customer = new BuilderCustomer().name("Tokio Marine Test").build();
		CreditCard payment = new BuilderCreditCard()
				.customer(customer)
				.brand(Brand.VISA)
				.cvv("123456")
				.expMonth(8)
				.expYear(2020)
				.holder("Tokio Marine Test")
				.number("4556379742764523")
				.build();
		ObjectMapper mapper = new ObjectMapper();
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.body(mapper.writeValueAsString(payment))
				.when()
				.post("v1/credit-cards")
				.then()
				.statusCode(400).log().all();
	}//@formatter:on

	@Test
	public void readTest() throws InterruptedException, JsonProcessingException {//@formatter:off
				given()
				.auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/credit-cards/5bbd1a6c3de5f237e06ab386")
				.then()
				.statusCode(200)
				.body("brand", equalTo(Brand.VISA.toString()))
				.body("cvv", equalTo("399"))
				.body("holder", equalTo("Tokio Marine Test")).log().all();
	}//@formatter:on

	@Test
	public void getTraceTest() throws InterruptedException, JsonProcessingException {//@formatter:off
				given().auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/credit-cards/5bbd1a6c3de5f237e06ab386/trace")
				.then()
				.statusCode(200).log().all();
	}//@formatter:on

	@Test
	public void notFoundGetOneCrediCardTest() throws InterruptedException, JsonProcessingException {//@formatter:off
				given().auth()
				.basic("admin", "admin")
				.contentType("application/json")
				.get("v1/credit-cards/5bbb9ef13de5f21d68ee480e9")
				.then()
				.statusCode(404)
				.body("error", equalTo("Not Found"))
				.body("message", equalTo("Resource not found")).log().all();
	}//@formatter:on

	@Test
	public void forbiddenUser() throws InterruptedException, JsonProcessingException {//@formatter:off
		Customer customer = new BuilderCustomer().name("Tokio Marine Test").build();
		CreditCard creditcard = new BuilderCreditCard().customer(customer).brand(Brand.VISA).cvv("399").expMonth(8)
				.expYear(2020)
				.holder("4556379742764523")
				.build();
		ObjectMapper mapper = new ObjectMapper();
				given()
				.auth()
				.basic("user", "user")
				.contentType("application/json")
				.body(mapper.writeValueAsString(creditcard))
				.when()
				.post("v1/credit-cards")
				.then()
				.statusCode(401).log().all();

	}//@formatter:on

}
