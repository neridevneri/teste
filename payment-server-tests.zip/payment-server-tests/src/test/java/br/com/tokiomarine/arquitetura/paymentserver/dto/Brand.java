package br.com.tokiomarine.arquitetura.paymentserver.dto;

public enum Brand {

	VISA, MASTERCARD, AMEX, ELO, DINERS, DISCOVER, JCB, AURA, HIPERCARD

}
