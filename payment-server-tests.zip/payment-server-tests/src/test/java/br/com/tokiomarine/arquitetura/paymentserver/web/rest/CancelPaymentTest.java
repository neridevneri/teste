package br.com.tokiomarine.arquitetura.paymentserver.web.rest;

import static com.jayway.restassured.RestAssured.*;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.isEmptyString;
import static org.hamcrest.Matchers.not;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.ResourceUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.http.ContentType;

@RunWith(SpringRunner.class)
@SpringBootTest
public class CancelPaymentTest {

	@Value("${payment-server.baseURI}")
	private String baseURI;

	@Value("${payment-server.username}")
	private String username;

	@Value("${payment-server.password}")
	private String password;

	@Before
	public void setup() {
		System.setProperty("http.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("http.proxyPort", "8080");
		System.setProperty("https.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("https.proxyPort", "8080");

		RestAssured.baseURI = baseURI;
		RestAssured.authentication = basic(username, password);
		RestAssured.enableLoggingOfRequestAndResponseIfValidationFails();
		RestAssured.requestSpecification = new RequestSpecBuilder().setContentType(ContentType.JSON)
				.setAccept(ContentType.JSON).build();
	}

	@Test
	public void cancelPayment() throws Throwable { // @formatter:off
		String id = createPaymentForTest();
		
		when().
	       delete("v1/payments/" + id).
	    then().
	    	statusCode(200).	    		    
	    	body("status", equalTo("CANCELED"));

	} // @formatter:on	

	private String createPaymentForTest() throws Throwable { // @formatter:off
		JsonNode json = getRequestBody("create-simple-payment.json");

		return given().			
			body(json).
		when().
	       post("v1/payments").
	    then().
	    	statusCode(201).
	    	body("id", not(isEmptyString())).
	    	body("status", equalTo("APPROVED")).
	    extract()
	    	.path("id");
	} // @formatter:on	

	private JsonNode getRequestBody(String filename) throws Throwable {
		File src = ResourceUtils.getFile("classpath:json/request/" + filename);
		return new ObjectMapper().readValue(src, JsonNode.class);
	}
}
