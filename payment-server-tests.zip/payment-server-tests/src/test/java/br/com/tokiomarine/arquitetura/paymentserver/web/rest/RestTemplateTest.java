package br.com.tokiomarine.arquitetura.paymentserver.web.rest;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.util.Base64Utils;
import org.springframework.web.client.RestTemplate;

@RunWith(SpringRunner.class)
@SpringBootTest
public class RestTemplateTest {

	@Value("${payment-server.baseURI}")
	private String baseURI;

	@Value("${payment-server.username}")
	private String username;

	@Value("${payment-server.password}")
	private String password;

	@Before
	public void setup() {
		System.setProperty("http.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("http.proxyPort", "8080");
		System.setProperty("https.proxyHost", "proxy.tokiomarine.com.br");
		System.setProperty("https.proxyPort", "8080");
	}

	@Test
	public void restTemplateWithBasicAuth() {
		String url = baseURI + "v1/payments";

		String plainCreds = username + ":" + password;
		String base64Creds = Base64Utils.encodeToString(plainCreds.getBytes());

		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Basic " + base64Creds);

		HttpEntity<String> entity = new HttpEntity<String>(headers);

		RestTemplate restTemplate = new RestTemplate();

		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);

		assertThat(response.getStatusCode().is2xxSuccessful()).isTrue();
	}

}
