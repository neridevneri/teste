package br.com.tokiomarine.arquitetura.paymentserver.builders;

import br.com.tokiomarine.arquitetura.paymentserver.dto.Customer;

public class BuilderCustomer {

	private Customer customer;

	public BuilderCustomer() {
		customer = new Customer();
	}

	public BuilderCustomer name(String name) {
		customer.setName(name);
		return this;
	}

	public BuilderCustomer document(String document) {
		customer.setDocument(document);
		return this;
	}

	public Customer build() {
		return customer;

	}

}
