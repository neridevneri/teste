package br.com.tokiomarine.arquitetura.paymentserver.builders;

import br.com.tokiomarine.arquitetura.paymentserver.dto.CreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.dto.Payment;
import br.com.tokiomarine.arquitetura.paymentserver.dto.PaymentStatus;

public class BuilderPayment {

   private Payment payment;
   
   
	public BuilderPayment() {
		payment = new Payment();
	}
	
	public BuilderPayment amount(int amount) {
		payment.setAmount(amount);
		return this;
	}
	
	public BuilderPayment creditCard(CreditCard creditCard) {
		payment.setCreditCard(creditCard);
		return this;
	}
	
	public BuilderPayment status(PaymentStatus status) {
		payment.setStatus(status);
		return this;
	}
	
	public BuilderPayment id(String id) {
		payment.setId(id);
		return this;
	}
	
	public Payment build() {
		return payment;

	}

}
