package br.com.tokiomarine.arquitetura.paymentserver.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.tokiomarine.arquitetura.paymentserver.dto.CreditCard;
import br.com.tokiomarine.arquitetura.paymentserver.dto.PaymentGatewayTrace;
import br.com.tokiomarine.arquitetura.paymentserver.dto.PaymentStatus;

public class Payment {

	private String id;
	private int amount;
	private CreditCard creditCard;

	@JsonIgnore
	private PaymentStatus status;

	@JsonIgnore
	private final PaymentGatewayTrace trace = new PaymentGatewayTrace();

	public Payment() {
		// TODO Auto-generated constructor stub
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public CreditCard getCreditCard() {
		return creditCard;
	}

	public void setCreditCard(CreditCard creditCard) {
		this.creditCard = creditCard;
	}

	public PaymentStatus getStatus() {
		return status;
	}

	public void setStatus(PaymentStatus status) {
		this.status = status;
	}

	public PaymentGatewayTrace getTrace() {
		return trace;
	}

}
